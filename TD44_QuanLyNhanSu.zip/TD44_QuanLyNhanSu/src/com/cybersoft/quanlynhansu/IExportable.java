package com.cybersoft.quanlynhansu;

public interface IExportable {
	Object exportExcel();
}
