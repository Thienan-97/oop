package quanlyhocsinh;

public interface IExportable {
	Object exportExcel();
}
