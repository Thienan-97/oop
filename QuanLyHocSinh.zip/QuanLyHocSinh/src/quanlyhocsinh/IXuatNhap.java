package quanlyhocsinh;

public interface IXuatNhap {
	void nhapThongTin();
	void xuatThongTin();
}

