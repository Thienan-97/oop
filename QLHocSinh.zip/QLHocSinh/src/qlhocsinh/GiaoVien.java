package qlhocsinh;

import java.util.Scanner;

public class GiaoVien extends Person {
	private String mon;
	private int lopChuNhiem;
	private float luongMotNgay;
	private float soNgayCong;
	
	
//	constructor
	public GiaoVien(String id, String name, String ngaySinh, String mon, int lopChuNhiem, float luongMotNgay,
			float soNgayCong) {
		super(id, name, ngaySinh);
		this.mon = mon;
		this.lopChuNhiem = lopChuNhiem;
		this.luongMotNgay = luongMotNgay;
		this.soNgayCong = soNgayCong;
	}
	
	public GiaoVien() {
		super();
		this.mon = "";
	}
	
//	get & set
	public String getMon() {
		return mon;
	}

	public void setMon(String mon) {
		this.mon = mon;
	}

	public int getLopChuNhiem() {
		return lopChuNhiem;
	}

	public void setLopChuNhiem(int lopChuNhiem) {
		this.lopChuNhiem = lopChuNhiem;
	}

	public float getLuongMotNgay() {
		return luongMotNgay;
	}

	public void setLuongMotNgay(float luongMotNgay) {
		this.luongMotNgay = luongMotNgay;
	}

	public float getSoNgayCong() {
		return soNgayCong;
	}

	public void setSoNgayCong(float soNgayCong) {
		this.soNgayCong = soNgayCong;
	}

//	method
	public double tinhLuong() {
		return luongMotNgay * soNgayCong;
	}
	
	static Scanner sc = new Scanner(System.in);
	
	@Override
	void nhapThongTin(Person[] p) {
		// TODO Auto-generated method stub
		System.out.print("Nhập id: ");
		id = sc.nextLine();
		System.out.print("Nhập họ tên: ");
		name = sc.nextLine();
		System.out.print("Nhập ngày sinh: ");
		ngaySinh = sc.nextLine();
		System.out.print("Môn: ");
		mon = sc.nextLine();
		System.out.print("Lớp chủ nhiệm: ");
		lopChuNhiem = Integer.parseInt(sc.nextLine());
		System.out.print("Lương một ngày: ");
		luongMotNgay = Float.parseFloat(sc.nextLine());
		System.out.print("Số ngày công: ");
		soNgayCong = Float.parseFloat(sc.nextLine());
	}

	protected Person[] p = new Person[100];
	@Override
	void showData() {
		// TODO Auto-generated method stub
		System.out.println(
				"---------------------------------------------------DANH SÁCH GIÁO VIÊN-----------------------------------------------");
		System.out.println(String.format(" %10s  ", "Mã số") + String.format("%13s  ", "Họ tên")
				+ String.format("%13s  ", "Ngày sinh") + String.format("%11s  ", "Môn")
				+ String.format("%13s  ", "Lớp CN") + String.format("%13s  ", "Lương 1 buổi")
				+ String.format("%15s  ", "Số ngày công") + String.format("%13s  ", "Lương"));
		System.out.println(
				"---------------------------------------------------------------------------------------------------------------------");
		for (int i = 0; i < p.length; i++) {
			if (p[i] instanceof GiaoVien) {
				System.out.println(String.format(" %10s  ", p[i].getId()) + String.format("%13s  ", p[i].getName())
						+ String.format("%13s  ", p[i].getNgaySinh())
						+ String.format("%11s  ", ((GiaoVien) p[i]).getMon())
						+ String.format("%13s  ", ((GiaoVien) p[i]).getLopChuNhiem())
						+ String.format("%13s  ", ((GiaoVien) p[i]).getLuongMotNgay())
						+ String.format("%15s  ", ((GiaoVien) p[i]).getSoNgayCong())
						+ String.format("%13s  ", ((GiaoVien) p[i]).tinhLuong()));
			}
		}
	}
	
}
