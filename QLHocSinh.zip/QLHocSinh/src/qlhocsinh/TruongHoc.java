package qlhocsinh;

import java.util.Scanner;

public class TruongHoc {
//	private int soLuong;
	private Person p[] = new Person[4];

//	Biến static 
	static Scanner sc = new Scanner(System.in);

//	tạo sẵn mảng dữ liệu
	public void dataList() {
//		HocSinh hs1 = new HocSinh("01", "An", "20/11", 6, "Tuấn", 25, 9, 4, 6, 4);
//		HocSinh hs2 = new HocSinh("02", "Ân", "9/7", 9, "Dương", 23, 8, 6, 7, 4);
//		GiaoVien gv1 = new GiaoVien("T01", "Tuấn", "11/11", "Toán", 6, 60, 20);
//		GiaoVien gv2 = new GiaoVien("A01", "Dương", "18/12", "Anh", 9, 60, 22);
//
//		p[0] = hs1;
//		p[1] = hs2;
//		p[2] = gv1;
//		p[3] = gv2;
	}

//	Thêm n phần tử vào mảng
//	public void addPerson() {
//		String id, hoTen, ngaySinh, giaoVienCN;
//		float soNgayHoc, soNgayLam, hocPhiMotBuoi, luongMotNgay, diemToan, diemVan, diemAnh;
//		int lop, lopChuNhiem, hanhKiem;
//		System.out.println("Nhập n: ");
//		int n = Integer.parseInt(sc.nextLine());
//		if (n < p.length) {
//			System.out.println("Nhập lại n: ");
//			n = Integer.parseInt(sc.nextLine());
//		}
//		Person[] pNew = arrayLengthChange(p, n);
//		int luaChon = menuAddPerson(sc);

	static void addStud(Person[] p) {
	   
		int lop;
		String giaoVienCN;
		float hocPhiMotBuoi;
		float soNgayHoc;
		float diemToan, diemVan, diemAnh;
		int hanhKiem;
	    int addMore;

	    do {
	        stud[i] = new Student(numID, year, userName, course);
	        ++i;

	        System.out.println("To add another Student Record Press 1");
	        addMore = sc.nextInt();
	    } while (addMore == 1);

	    }

	switch(luaChon)

	{
		case 1:
//			for (int i = p.length; i < pNew.length; i++) {
////				nhập thông tin
//				System.out.print("Nhập id: ");
//				id = sc.nextLine();
//				System.out.print("Nhập họ tên: ");
//				hoTen = sc.nextLine();
//				System.out.print("Nhập ngày sinh: ");
//				ngaySinh = sc.nextLine();
//				System.out.print("Lớp: ");
//				lop = Integer.parseInt(sc.nextLine());
//				System.out.print("Nhập giáo viên chủ nhiệm: ");
//				giaoVienCN = sc.nextLine();
//				System.out.print("Học phí một buổi: ");
//				hocPhiMotBuoi = Float.parseFloat(sc.nextLine());
//				System.out.print("Số ngày học: ");
//				soNgayHoc = Float.parseFloat(sc.nextLine());
//				System.out.print("Điểm toán: ");
//				diemToan = Float.parseFloat(sc.nextLine());
//				System.out.print("Điểm anh: ");
//				diemAnh = Float.parseFloat(sc.nextLine());
//				System.out.print("Điểm văn: ");
//				diemVan = Float.parseFloat(sc.nextLine());
//				System.out.print("Hạnh kiểm: ");
//				hanhKiem = Integer.parseInt(sc.nextLine());
//
////				lưu thông tin vào phần tử của mảng
//				HocSinh hs = new HocSinh(id, hoTen, ngaySinh, lop, giaoVienCN, soNgayHoc, diemToan, diemVan, diemAnh,
//						hanhKiem);
//				pNew[i] = hs;
//			}
//			System.out.println(
//					"----------------------------------------------DANH SÁCH HỌC SINH------------------------------------------");
//			System.out.println(String.format(" %10s  ", "Mã số") + String.format("%13s  ", "Họ tên")
//					+ String.format("%13s  ", "Ngày sinh") + String.format("%11s  ", "Lớp")
//					+ String.format("%13s  ", "GVCN") + String.format("%15s  ", "Số ngày học"));
//			System.out.println(
//					"----------------------------------------------------------------------------------------------------------");
//			for (int i = 0; i < pNew.length; i++) {
//				if (pNew[i] instanceof HocSinh) {
//					System.out.println(
//							String.format(" %10s  ", pNew[i].getId()) + String.format("%13s  ", pNew[i].getName())
//									+ String.format("%13s  ", pNew[i].getNgaySinh())
//									+ String.format("%11s  ", ((HocSinh) pNew[i]).getLop())
//									+ String.format("%13s  ", ((HocSinh) pNew[i]).getGiaoVienCN())
//									+ String.format("%15s  ", ((HocSinh) pNew[i]).getSoNgayHoc()));
//				}
//			}
			
			break;
		case 0:
			System.out.println("Kết thúc chương trình.");
			break;
		default:
			System.out.println("Lựa chọn không hợp lệ.");
			break;
		}
	}

//		for (int i = p.length; i < pNew.length; i++) {
//			if (p[i] instanceof HocSinh) {
//				System.out.println(String.format(" %10s  ", pNew[i].getId())
//						+ String.format("%13s  ", pNew[i].getName()) + String.format("%13s  ", pNew[i].getNgaySinh())
//						+ String.format("%11s  ", ((HocSinh) pNew[i]).getLop())
//						+ String.format("%13s  ", ((HocSinh) pNew[i]).getGiaoVienCN())
//						+ String.format("%15s  ", ((HocSinh) pNew[i]).getSoNgayHoc())));
//			} else if (pNew[i] instanceof GiaoVien) {
//				System.out.println(String.format(" %10s  ", pNew[i].getId())
//						+ String.format("%13s  ", pNew[i].getName()) + String.format("%13s  ", pNew[i].getNgaySinh())
//						+ String.format("%11s  ", ((GiaoVien) pNew[i]).getMon())
//						+ String.format("%13s  ", ((GiaoVien) pNew[i]).getLopChuNhiem())
//						+ String.format("%13s  ", ((GiaoVien) pNew[i]).getLuongMotNgay())
//						+ String.format("%15s  ", ((GiaoVien) pNew[i]).getSoNgayCong())
//						+ String.format("%13s  ", ((GiaoVien) pNew[i]).tinhLuong()));
//			}
//		}

//	menu lựa chọn thêm học sinh hay giáo viên
//	static int menuAddPerson(Scanner sc) {
//		int spaceNum = 20;
//		System.out.println(
//				String.format("%" + spaceNum + "s", "") + "QUẢN LÝ NHÂN SỰ" + String.format("%" + spaceNum + "s", ""));
//		System.out.println("Menu:");
//		System.out.println("\t1. Thêm học sinh");
//		System.out.println("\t2. Thêm giáo viên");
//		System.out.println("\t0. Thoát.");
//		System.out.print("Lựa chọn: ");
//		return Integer.parseInt(sc.nextLine());
//	}
//
////	thay đổi kích thước mảng
//	static Person[] arrayLengthChange(Person[] arr, int newLength) {
//		Person[] arrNew = new Person[newLength];
//		System.arraycopy(arr, 0, arrNew, 0, arr.length);
//		return arrNew;
//	}

//	1. xuất danh sách học sinh
//	public void showDataHocSinh() {
//		System.out.println(
//				"----------------------------------------------DANH SÁCH HỌC SINH------------------------------------------");
//		System.out.println(String.format(" %10s  ", "Mã số") + String.format("%13s  ", "Họ tên")
//				+ String.format("%13s  ", "Ngày sinh") + String.format("%11s  ", "Lớp")
//				+ String.format("%13s  ", "GVCN") + String.format("%15s  ", "Số ngày học"));
//		System.out.println(
//				"----------------------------------------------------------------------------------------------------------");
//		for (int i = 0; i < p.length; i++) {
//			if (p[i] instanceof HocSinh) {
//				System.out.println(String.format(" %10s  ", p[i].getId()) + String.format("%13s  ", p[i].getName())
//						+ String.format("%13s  ", p[i].getNgaySinh())
//						+ String.format("%11s  ", ((HocSinh) p[i]).getLop())
//						+ String.format("%13s  ", ((HocSinh) p[i]).getGiaoVienCN())
//						+ String.format("%15s  ", ((HocSinh) p[i]).getSoNgayHoc()));
//			}
//		}
//	}

//	2. xuất danh sách xếp loại học sinh
	public void showDataDiemVaXepLoai() {
		System.out.println(
				"-----------------------------------------------------------------DANH SÁCH HỌC SINH------------------------------------------------------");
		System.out.println(
				String.format(" %10s  ", "Mã số") + String.format("%13s  ", "Họ tên") + String.format("%13s  ", "Lớp")
						+ String.format("%13s  ", "Điểm toán") + String.format("%13s  ", "Điểm Văn")
						+ String.format("%13s  ", "Điểm anh") + String.format("%13s  ", "Hạnh kiểm")
						+ String.format("%13s  ", "Điểm trung bình") + String.format("%15s  ", "Xếp loại"));
		System.out.println(
				"-----------------------------------------------------------------------------------------------------------------------------------------");
		for (int i = 0; i < p.length; i++) {
			if (p[i] instanceof HocSinh) {
				System.out.println(String.format(" %10s  ", p[i].getId()) + String.format("%13s  ", p[i].getName())
						+ String.format("%13s  ", ((HocSinh) p[i]).getLop())
						+ String.format("%13s  ", ((HocSinh) p[i]).getDiemToan())
						+ String.format("%13s  ", ((HocSinh) p[i]).getDiemVan())
						+ String.format("%13s  ", ((HocSinh) p[i]).getDiemAnh())
						+ String.format("%13s  ", ((HocSinh) p[i]).getHanhKiem())
						+ String.format("%15s  ", ((HocSinh) p[i]).tinhDiemTrungBinh())
						+ String.format("%15s  ", ((HocSinh) p[i]).xepLoaiHocSinh()));
			}
		}
	}

//	3. xuất danh sách giáo viên
//	public void showDataGiaoVien() {
//		System.out.println(
//				"---------------------------------------------------DANH SÁCH GIÁO VIÊN-----------------------------------------------");
//		System.out.println(String.format(" %10s  ", "Mã số") + String.format("%13s  ", "Họ tên")
//				+ String.format("%13s  ", "Ngày sinh") + String.format("%11s  ", "Môn")
//				+ String.format("%13s  ", "Lớp CN") + String.format("%13s  ", "Lương 1 buổi")
//				+ String.format("%15s  ", "Số ngày công") + String.format("%13s  ", "Lương"));
//		System.out.println(
//				"---------------------------------------------------------------------------------------------------------------------");
//		for (int i = 0; i < p.length; i++) {
//			if (p[i] instanceof GiaoVien) {
//				System.out.println(String.format(" %10s  ", p[i].getId()) + String.format("%13s  ", p[i].getName())
//						+ String.format("%13s  ", p[i].getNgaySinh())
//						+ String.format("%11s  ", ((GiaoVien) p[i]).getMon())
//						+ String.format("%13s  ", ((GiaoVien) p[i]).getLopChuNhiem())
//						+ String.format("%13s  ", ((GiaoVien) p[i]).getLuongMotNgay())
//						+ String.format("%15s  ", ((GiaoVien) p[i]).getSoNgayCong())
//						+ String.format("%13s  ", ((GiaoVien) p[i]).tinhLuong()));
//			}
//		}
//	}

//	4. Thêm mới 1 học sinh
//	public void addHosSinh(Person p) {
//
//	}

}
