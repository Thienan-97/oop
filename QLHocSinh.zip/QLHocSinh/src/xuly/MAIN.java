package xuly;

import qlhocsinh.Person;

import java.util.Scanner;

import javax.swing.plaf.basic.BasicScrollPaneUI.HSBChangeListener;

import qlhocsinh.HocSinh;
import qlhocsinh.TruongHoc;

public class MAIN {
	static Scanner sc = new Scanner(System.in);
	TruongHoc truong = new TruongHoc();
	static int i = 0;
	static Person[] p = new HocSinh[100];
//	truong.dataList();
	public static void main(String[] args) {
		HocSinh hs = new HocSinh();
		int luaChon;
		/*
		 * Menu quản lý nhân sự
		 */
		do {
			luaChon = inMenu(sc);

			switch (luaChon) {
			case 1:
				
				hs.addData();
				break;
			case 2:
				hs.showData();
				break;
//			case 3:
//				truong.showDataGiaoVien();
//				break;
//			case 4:
//				truong.addPerson();
//				break;
			case 0:
				System.out.println("Kết thúc chương trình.");
				break;
			default:
				System.out.println("Lựa chọn không hợp lệ.");
				break;
			}
			sc.nextLine();
		} while (luaChon != 0);
	}

//	Phương thức static
	static int inMenu(Scanner sc) {
		int spaceNum = 20;
		System.out.println(
				String.format("%" + spaceNum + "s", "") + "QUẢN LÝ HỌC SINH" + String.format("%" + spaceNum + "s", ""));
		System.out.println("Menu:");
		System.out.println("\t1. Thêm học sinh");
		System.out.println("\t2. Xuất danh sách xếp loại học sinh");
		System.out.println("\t3. Xuất danh sách giáo viên");
		System.out.println("\t4. Thêm học sinh");
//        System.out.println("\t5. Tính và xuất tổng lương cho toàn công ty");
//        System.out.println("\t6. Tìm Nhân viên thường có lương cao nhất");
//        System.out.println("\t7. Tìm Trưởng Phòng có số lượng nhân viên dưới quyền nhiều nhất");
//        System.out.println("\t8. Sắp xếp nhân viên toàn công ty theo thứ tự abc");
//        System.out.println("\t9. Sắp xếp nhân viên toàn công ty theo thứ tự lương giảm dần");
//        System.out.println("\t10. Tìm Giám Đốc có số lượng cổ phần nhiều nhất");
//        System.out.println("\t11. Tính và Xuất tổng THU NHẬP của từng Giám Đốc");
		System.out.println("\t0. Thoát.");
		System.out.print("Lựa chọn: ");
		return Integer.parseInt(sc.nextLine());
	}

}
